const accountSummaryData = [
  {
    account_id: "1",
    deposits: 1,
    withdrawals: 2,
    cancelled_withdrawals: 1,
    closed_trade_profit: 13.6,
    closed_trade_loss: 20.4
  },
  {
    account_id: "1",
    deposits: 1,
    withdrawals: 2,
    cancelled_withdrawals: 1,
    closed_trade_profit: 13.6,
    closed_trade_loss: 20.4
  },
  {
    account_id: "1",
    deposits: 1,
    withdrawals: 2,
    cancelled_withdrawals: 1,
    closed_trade_profit: 13.6,
    closed_trade_loss: 20.4
  },
  {
    account_id: "1",
    deposits: 1,
    withdrawals: 2,
    cancelled_withdrawals: 1,
    closed_trade_profit: 13.6,
    closed_trade_loss: 20.4
  },
]

module.exports = accountSummaryData