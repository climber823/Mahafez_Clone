const statementData = [
  {
    account_id: "1",
    open_time: new Date(),
    action: "withdraw",
    more_details: "",
    amount: 1000,
  },
  {
    account_id: "1",
    open_time: new Date(),
    action: "withdraw",
    more_details: "",
    amount: 1000,
  },
  {
    account_id: "1",
    open_time: new Date(),
    action: "withdraw",
    more_details: "",
    amount: 1000,
  },
]

module.exports = statementData