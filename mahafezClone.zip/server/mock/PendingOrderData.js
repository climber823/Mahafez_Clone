const pendingOrderData = [
  {
    account_id: "1",
    open_time: new Date(),
    deal_type: "buy",
    order_rate: 1.2,
    market_rate: 3.4,
    stop_loss: 3.2,
    take_profit: 4.5,
    actions: "Buy",
  },
  {
    account_id: "1",
    open_time: new Date(),
    deal_type: "buy",
    order_rate: 1.2,
    market_rate: 3.4,
    stop_loss: 3.2,
    take_profit: 4.5,
    actions: "Buy",
  },
]

module.exports = pendingOrderData