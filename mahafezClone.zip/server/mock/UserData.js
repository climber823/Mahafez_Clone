const userData = [
  {
    account_id: "1",
    email: "orest@gmail.com",
    firstname: "orest",
    lastname: "zelisko",
    phone: "123456789",
    password: "123",
  },
]

module.exports = userData